for i in *.wav; do
 oggenc -o ${i%.*}.ogg $i
 rm $i
done

